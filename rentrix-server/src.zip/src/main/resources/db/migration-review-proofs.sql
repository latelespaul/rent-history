-- Create new table
CREATE TABLE IF NOT EXISTS review_proofs
(
   id                BIGINT AUTO_INCREMENT PRIMARY KEY,
   review_id         BIGINT       NOT NULL,
   storage_key       VARCHAR(500) NOT NULL,
   original_filename VARCHAR(255),
   content_type      VARCHAR(100) NOT NULL,
   size_bytes        BIGINT       NOT NULL,
   display_order     INT          NOT NULL DEFAULT 0,
   verified          BOOLEAN      NOT NULL DEFAULT FALSE,
   deleted           BOOLEAN      NOT NULL DEFAULT FALSE,
   created_at        TIMESTAMP    NOT NULL,
   updated_at        TIMESTAMP    NOT NULL,
   CONSTRAINT fk_review_proofs_review
      FOREIGN KEY (review_id) REFERENCES reviews (id)
         ON DELETE CASCADE
);

CREATE INDEX idx_review_proofs_review ON review_proofs (review_id);
CREATE INDEX idx_review_proofs_order ON review_proofs (review_id, display_order);

-- Migrate existing single-proof rows (if any)
-- Run this ONLY if the old columns exist and have data
INSERT INTO review_proofs (review_id, storage_key, content_type, size_bytes, display_order, verified, deleted,
                           created_at, updated_at)
SELECT id,
       proof_storage_key,
       proof_content_type,
       0,
       0,
       proof_verified,
       FALSE,
       NOW(),
       NOW()
FROM reviews
WHERE proof_storage_key IS NOT NULL;

-- Drop old columns (safety: run after verifying the data migrated)
ALTER TABLE reviews
   DROP COLUMN proof_storage_key;
ALTER TABLE reviews
   DROP COLUMN proof_content_type;
ALTER TABLE reviews
   DROP COLUMN proof_uploaded_at;
ALTER TABLE reviews
   DROP COLUMN proof_verified;