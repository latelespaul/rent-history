CREATE TABLE IF NOT EXISTS flat_images
(
   id                BIGINT AUTO_INCREMENT PRIMARY KEY,
   flat_id           BIGINT        NOT NULL,
   storage_key       VARCHAR(500)  NOT NULL,
   public_url        VARCHAR(1000) NOT NULL,
   content_type      VARCHAR(100)  NOT NULL,
   size_bytes        BIGINT        NOT NULL,
   original_filename VARCHAR(255),
   display_order     INT           NOT NULL DEFAULT 0,
   is_primary        BOOLEAN       NOT NULL DEFAULT FALSE,
   deleted           BOOLEAN       NOT NULL DEFAULT FALSE,
   created_at        TIMESTAMP     NOT NULL,
   updated_at        TIMESTAMP     NOT NULL,
   CONSTRAINT fk_flat_images_flat
      FOREIGN KEY (flat_id) REFERENCES flats (id)
         ON DELETE CASCADE
);

CREATE INDEX idx_flat_images_flat ON flat_images (flat_id);
CREATE INDEX idx_flat_images_order ON flat_images (flat_id, display_order);